void main(void)
{
    1 + 2;
    1 - 2;
}
