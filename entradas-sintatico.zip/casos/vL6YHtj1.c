void main(void)
{
    if(1 == 1) if(2 == 2) 3+3; else 4+4;
}
