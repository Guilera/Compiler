int var0;
int var1[var0];
void main(void) {}
