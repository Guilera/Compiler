int foo(void)
{
    return 1;
}

void main(void)
{
    foo + 1;
}
