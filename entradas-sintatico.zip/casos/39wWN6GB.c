void main(void)
{
    int x;
    int y;

    x y;
}
