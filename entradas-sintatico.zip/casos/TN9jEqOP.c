int x;

void foo(void)
{
}

int y[10];

void bar(x, int y)  /* this is a bad decl */
{
}

void baz(void)
{
}

int z;
int w;

void another(x) /* another bad decl */
{
}

int j[9];
int k;

void main(void)
{
}
