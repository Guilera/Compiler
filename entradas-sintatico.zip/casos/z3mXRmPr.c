void foo(void)
{
}

int bar(void)
{
    return foo();
}

void main(void)
{
}
