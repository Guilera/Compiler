void foo(int a[10])
{
}

void main(void) {}
