void foo(void)
{
    int x;
}

void main(void)
{
    x = 10;
}
