void main(void)
{
    main() + 1;
}
