void main(void)
{
    int x;
    int y;
    int z;
    int w;
    int k;
    int j[20];

    x * y - 4 / z + w * (k + 2) + j[10] - j[x] - j[x-2];
}
