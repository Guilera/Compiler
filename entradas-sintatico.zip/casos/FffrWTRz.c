type foo(void)
{
}

void main(void) {}
