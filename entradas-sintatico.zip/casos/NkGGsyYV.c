void main(void)
{
    int x;
    x = println(x);
}
