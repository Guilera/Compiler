void main(void)
{
    int x;

    if(1 == 1)
        x + 1;

    if(1 == 1)
        1;

    if(1 == 1)
        (2);

    if(1 == 1);

    if(1 == 1)
    {
    }

    if(1 == 1)
        if(2 == 2);

    if(1 == 1)
        while(3 == 3);

    if(1 == 1)
        return;

    if(1 == 1);
    else x + 1;

    if(1 == 1);
    else 1;

    if(1 == 1);
    else (2);

    if(1 == 1);
    else;

    if(1 == 1);
    else {}

    if(1 == 1);
    else if(2 == 2);

    if(1 == 1);
    else while(3 == 3);

    if(1 == 1);
    else return;
}
