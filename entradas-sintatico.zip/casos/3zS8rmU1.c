void main(void) { (); }
