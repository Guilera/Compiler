void main(void)
{
    int j[10];
    int x;

    j[x;
}
