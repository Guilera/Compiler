void foo(int arr[])
{
}

void main(void) {}
