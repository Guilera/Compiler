void foo(void)
{
}

void foo(void)
{
}

void main(void)
{
}
