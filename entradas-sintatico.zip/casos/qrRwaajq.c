void main(void)
{
    main(;
}
