void main(void)
{
    int x;
    int y;

    x = y;
    x = 10;
    x = (1 + 2) * y;
}
