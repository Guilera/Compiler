void main(void)
{
    int x;
    {
        int x;
    }
}
