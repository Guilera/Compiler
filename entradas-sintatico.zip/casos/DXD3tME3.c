void foo(void)
{
}

void foo(int x)
{
}

void main(void)
{
}
