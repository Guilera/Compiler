void f0(void)
{
    /* empty */
}

void f1(void)
{
    /* three statements */
    1;
    2;
    3;
}

void f2(void)
{
    /* a single statement */
    1;
}

void main(void)
{
}
