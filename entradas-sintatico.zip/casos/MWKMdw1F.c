(void)
{
}

void main(void) {}
