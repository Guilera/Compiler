void foo(int p)
{
}

void main(void)
{
    foo(5);
}
