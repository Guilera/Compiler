void main(void)
{
    int x;
    x = main();
}
