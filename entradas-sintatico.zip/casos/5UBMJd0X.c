void main(void)
{
    int x;

    while(1 == 1)
        x + 1;

    while(1 == 1)
        1;

    while(1 == 1)
        (2);

    while(1 == 1);

    while(1 == 1)
    {
    }

    while(1 == 1)
        if(2 == 2);

    while(1 == 1)
        while(3 == 3);

    while(1 == 1)
        return;
}
