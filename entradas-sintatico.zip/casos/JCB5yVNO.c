void main(void)
{
    ;
}
