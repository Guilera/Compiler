void main(void)
{
    {
        int x;
        int y;
        int z;
    }
}
