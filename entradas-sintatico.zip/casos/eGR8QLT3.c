void main(void)
{
    if(1 == 1) 1;
    else if(2 == 2) 2;
    else if(3 == 3) 3;
    else if(4 == 4) 4;
}
