int foo(void)
{
    return bar();
}

int bar(void)
{
    return 0;
}

void main(void)
{
}
