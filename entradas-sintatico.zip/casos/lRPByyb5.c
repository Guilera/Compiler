void main(void) { 1; }
