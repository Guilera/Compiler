void foo(void x)
{
}

void main(void)
{
}
