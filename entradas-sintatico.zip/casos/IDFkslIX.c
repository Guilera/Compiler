void (void)
{
}

void main(void) {}
