int var1[10]
void main(void) {}
