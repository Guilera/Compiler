void f0(void)
{
    int x;
    int y
    int z;
}

void main(void)
{
}
