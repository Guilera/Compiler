void foo(int a[])
{
}

void main(void)
{
    int a[10];
    foo(a + 1);
}
