void foo(void)
{
}

int foo;

void main(void)
{
}
