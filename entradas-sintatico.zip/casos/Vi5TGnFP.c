void main(void)
{
    int a[10];
    a[20];
}
