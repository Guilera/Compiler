void main(void)
{
    int x[10];
    x = main();
}
