int foo;

void bar(void)
{
    int foo;
}

void main(void)
{
}
