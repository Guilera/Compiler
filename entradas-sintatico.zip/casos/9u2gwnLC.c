int var1;
var1;
void main(void) {}
