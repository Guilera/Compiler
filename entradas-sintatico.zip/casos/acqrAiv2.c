void main(void)
{
    int x;
    int y[10];
    x = y;
}
