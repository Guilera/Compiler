void foo(void)
{
}

void bar(void)
{
    int foo;
}

void main(void)
{
}
