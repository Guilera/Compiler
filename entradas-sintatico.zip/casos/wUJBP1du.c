int sum(int x){
  if(x>0)
    return x + sum(x-1);
  return 0;
}

void main(void){
  println(sum(10));
}
