void main(void)
{
    while(main()) {}
}
