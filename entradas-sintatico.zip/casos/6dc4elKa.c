void foo(int x)
{
}

void main(void)
{
    x = 1;
}
