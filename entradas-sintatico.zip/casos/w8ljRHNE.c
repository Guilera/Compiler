void main(void)
{
    {
        1 + 2;
        2 + 3;
    }
}
