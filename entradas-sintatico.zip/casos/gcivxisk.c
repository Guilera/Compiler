void main(void)
{
    void x;
}
