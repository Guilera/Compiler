void main(void)
{
    int a[10];
    main() + a;
}
