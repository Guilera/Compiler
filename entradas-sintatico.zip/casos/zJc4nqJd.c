int var1 10]; /* expects semicolon, but got a number */
void main(void) {}
