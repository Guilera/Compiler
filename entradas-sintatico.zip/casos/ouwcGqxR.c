void main(void)
{
    [10];
}
