void main(void)
{
    int x[100];
    int y;
    int z;
    int w;

    x[0];
    x[1];
    x[99];
    x[y];
    x[1 + y * (z - w)];
}
