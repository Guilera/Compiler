void main(void)
{
    while(1) {}
}
