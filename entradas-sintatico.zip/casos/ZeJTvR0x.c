void main(void)
{
    while(*);
}
