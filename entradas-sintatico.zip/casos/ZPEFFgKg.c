void main(void)
{
    int x[10];
    main() = x;
}
