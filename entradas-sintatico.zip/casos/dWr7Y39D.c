void main(void)
{
    1 + 1;
    int x;
}
