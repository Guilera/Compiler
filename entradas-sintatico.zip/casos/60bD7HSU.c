void foo(int x)
{
    {
        int x;
    }
}

void main(void)
{
}
