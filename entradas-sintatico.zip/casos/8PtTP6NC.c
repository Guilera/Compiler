void main(void)
{
    if(main()) {}
}
