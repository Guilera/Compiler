void main(void)
{
    1 = 2;
}
