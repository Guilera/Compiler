void foo(int a, , int c)
{
}

void main(void) {}
