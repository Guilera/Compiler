int foo(void)
{
    return bar;
}

int bar;

void main(void)
{
}
