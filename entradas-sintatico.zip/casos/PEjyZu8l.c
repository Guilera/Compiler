void foo(void)
{
}

void main(void)
{
    foo = 1;
}
