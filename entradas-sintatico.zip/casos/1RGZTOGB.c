int var1
void main(void) {}
