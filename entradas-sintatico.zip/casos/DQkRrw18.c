void foo(int p[])
{
}

void main(void)
{
    int x;
    foo(x);
}
