void foo(int)
{
}

void main(void) {}
