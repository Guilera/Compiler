void main(void)
{
    input(1);
}
