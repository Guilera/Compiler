void main(void)
{
    main);
}
