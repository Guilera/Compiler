void main(void)
{
    int x;
    x + x;
    int y;
    x + x;
}
