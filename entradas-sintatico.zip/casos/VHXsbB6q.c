void main(void)
{
    1 + 1;
}
