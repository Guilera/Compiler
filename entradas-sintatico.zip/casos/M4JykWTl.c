int foo;

void bar(int foo)
{
}

void main(void)
{
}
