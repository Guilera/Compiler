void foo()
{
}

void main(void) {}
