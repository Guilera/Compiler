void main(void)
{
    void foo(void)
    {
    }
}
