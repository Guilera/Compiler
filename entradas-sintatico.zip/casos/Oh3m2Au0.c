int var1, var2;
void main(void) {}
