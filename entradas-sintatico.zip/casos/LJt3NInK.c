void main(void) { return 1 < ; }
