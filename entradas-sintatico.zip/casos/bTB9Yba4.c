void foo(void stuff)
{
}

void main(void) {}
