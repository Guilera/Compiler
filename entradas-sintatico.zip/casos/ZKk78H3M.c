int x;
int y;
int arr[10];

void main(void)
{
    x = y = 10;

    x = y = arr[0];

    arr[0] = y = x = 10 * x;
}
