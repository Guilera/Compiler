void main(void)
{
    int oof[10][10];
}
