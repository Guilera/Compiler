void foo(void)
{
}

void main(void) {}
