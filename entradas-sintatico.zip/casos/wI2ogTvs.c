void main(void)
{
    main() + main();
}
