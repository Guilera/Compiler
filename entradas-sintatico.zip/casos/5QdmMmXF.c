void main(void)
{
    main;
}
