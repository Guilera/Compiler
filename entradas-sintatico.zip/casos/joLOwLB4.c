void foo(void)
{
}

int bar(void)
{
    return 1;
}

void main(void) {}
