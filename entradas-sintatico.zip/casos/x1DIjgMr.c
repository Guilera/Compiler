void main(void)
{
    2
}
