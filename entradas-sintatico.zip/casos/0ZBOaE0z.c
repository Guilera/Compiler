void foo(int p[])
{
}

void main(void)
{
    int a[10];
    foo(a);
}
