void foo(void)
{
    1 + 1;
    2 * 2;
}

void main(void)
{
}
