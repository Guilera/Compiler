void main(void)
{
    int x;
    x = input();
    println(x);
}
