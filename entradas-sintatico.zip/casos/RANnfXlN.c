int a
int b
int c
int d;
int e;
int f
int g;

void foo(void)
{
}

int h

void bar(void)
{
}

void main(void) {}
