void foo(int a, int b, int c)
{
}

void main(void) {}
