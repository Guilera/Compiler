void main(void)
{
    int a[10];
    1 + a;
}
