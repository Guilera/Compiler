
void main(void)
{
    *;
}

