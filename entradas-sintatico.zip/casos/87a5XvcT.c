void main(void)
{
    return main();
}
