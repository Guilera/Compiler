void foo(void, int a)
{
}

void main(void) {}
