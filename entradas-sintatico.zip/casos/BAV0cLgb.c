void main(void)
{
    if(1 == 1)
        2;
    else
        *;
}
