void main(void)
{
  int a;
  a = 4 + 5;
}
