void foo(int x, int y)
{
}

void main(void)
{
    foo(,);
}
