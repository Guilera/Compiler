int foo(void)
{
    int a[10];
    return a;
}

void main(void)
{
}
