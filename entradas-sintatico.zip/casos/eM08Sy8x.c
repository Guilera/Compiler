void main(void)
{
    int x; int y; int w;
    x = y = 10 = w;
}
