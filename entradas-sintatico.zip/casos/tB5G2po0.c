void foo(type a)
{
}

void main(void) {}
