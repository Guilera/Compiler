void main(void)
{
    2[3];
}
