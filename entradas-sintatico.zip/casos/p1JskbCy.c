void main(void)
{
    int x[10];
    int y[10];
    x[y] = 1;
}
