void foo(int a, int b[], int c, int d, int e[])
{
}

void main(void) {}
