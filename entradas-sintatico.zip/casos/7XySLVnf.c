void foo(int a + int b)
{
}

void main(void) {}
