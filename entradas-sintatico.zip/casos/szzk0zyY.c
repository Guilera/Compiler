void main(void)
{
    if 1 == 1
    {
    }
}
