void main(void)
{
    if(1) {}
}
