void main(void)
{
    int while;
}
