void foo(int a, int)
{
}

void main(void) {}
