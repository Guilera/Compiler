int x;

void foo(void)
{
}

int bar(int x, int y)
{
}

int y[10];

int baz(void)
{
}

int z;
int w;
int j[9];
int k;

void main(void)
{
}
