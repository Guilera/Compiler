void main(void)
{
    j[];
}
