int foo;

void main(void)
{
    foo();
}
