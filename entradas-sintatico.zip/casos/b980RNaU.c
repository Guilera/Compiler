void foo(int x)
{
}

void main(void)
{
    foo(main());
}
