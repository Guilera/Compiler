int foo(void)
{
    return;
}

void main(void)
{
}
