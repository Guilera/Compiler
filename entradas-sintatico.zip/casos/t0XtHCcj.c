void main(void)
{
    while 1 == 1 ;
}
