void foo(int p[])
{
}

void main(void)
{
    foo(main());
}
