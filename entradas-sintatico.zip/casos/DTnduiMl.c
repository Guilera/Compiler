void foo(int a[])
{
    a;
}

void main(void)
{
}
