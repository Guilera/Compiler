void main(void)
{
    if(*);
}
