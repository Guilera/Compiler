int foo;

void foo(void)
{
}

void main(void)
{
}
