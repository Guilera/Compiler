void main(void)
{
    int x;
    x = 1;
}
