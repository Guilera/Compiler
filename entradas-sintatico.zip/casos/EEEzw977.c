void foo(a)
{
}

void main(void) {}
