void foo(int a[])
{
    a[0] = 1;
}

void main(void)
{
}
