int foo(int x, int y)
{
    return foo(x+1, y-1);
}

void main(void)
{
    main();
}
