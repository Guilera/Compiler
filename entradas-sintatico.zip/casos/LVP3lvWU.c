void main(void)
{
    int x;
    int y;
    int arr[10];

    x;
    y;
    arr[1];
    arr[x];
    arr[x+2];
}
