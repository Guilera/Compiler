void foo(void)
{
}

void bar(int foo)
{
}

void main(void)
{
}
