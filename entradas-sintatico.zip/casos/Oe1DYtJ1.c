void f0(void)
{
    /* local-declarations with one item */
    int x;
}

void f1(void)
{
    /* local-declarations with three items */
    int x;
    int y;
    int z[10];
}

void f2(void)
{
    /* empty local-declarations */
}

void main(void)
{
}
