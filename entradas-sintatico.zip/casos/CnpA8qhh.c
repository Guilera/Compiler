void main(void)
{
    if(1 == 1)
        1;
    else
        2;

    if(1 == 1)
        3;
}
