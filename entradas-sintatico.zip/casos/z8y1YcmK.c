void main(void)
{
    int x[10];
    x[1] = 1;
}
