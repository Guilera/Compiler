void foo(void)
{
}

void baz(int x)
{
}

void bar(int x, int y)
{
}

void main(void)
{
    foo();
    baz(1);
    bar(1, 2);
}
