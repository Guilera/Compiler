void foo(int a[)
{
}

void main(void) {}
