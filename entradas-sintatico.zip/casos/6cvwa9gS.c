int foo;

int foo;

void main(void)
{
}
